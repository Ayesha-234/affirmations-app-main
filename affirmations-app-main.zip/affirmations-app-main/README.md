# Affirmations App

Some fun and positive affirmations to remind yourself

# App Location
```bash
app > release > app-release.apk
```


made using Kotlin and Jetpack Compose
